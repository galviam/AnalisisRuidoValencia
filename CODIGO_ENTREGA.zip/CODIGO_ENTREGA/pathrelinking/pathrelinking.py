from structure import solution

def path_relinking(init_sol, guide_sol, max_steps=20):
    """
    Path Relinking determinista (sin aleatoriedad), más exhaustivo.
    En cada paso, prueba todas las combinaciones (u, v) y elige la mejor.

    Parámetros:
    - init_sol: solución de inicio
    - guide_sol: solución guía
    - max_steps: número máximo de pasos permitidos

    Retorna:
    - La mejor solución encontrada durante el camino
    """
    current = {
        'sol': init_sol['sol'].copy(),
        'of': init_sol['of'],
        'instance': init_sol['instance']
    }
    best = {
        'sol': init_sol['sol'].copy(),
        'of': init_sol['of'],
        'instance': init_sol['instance']
    }

    steps = 0

    while current['sol'] != guide_sol['sol'] and steps < max_steps:
        to_add = guide_sol['sol'] - current['sol']
        to_remove = current['sol'] - guide_sol['sol']

        best_candidate = None
        best_value = -1

        for u in to_remove:
            for v in to_add:
                candidate = {
                    'sol': current['sol'].copy(),
                    'of': current['of'],
                    'instance': current['instance']
                }
                solution.removeFromSolution(candidate, u)
                solution.addToSolution(candidate, v)

                if candidate['of'] > best_value:
                    best_value = candidate['of']
                    best_candidate = candidate

        if best_candidate is None:
            break  # por seguridad

        current = best_candidate
        steps += 1

        if current['of'] > best['of']:
            best = {
                'sol': current['sol'].copy(),
                'of': current['of'],
                'instance': current['instance']
            }

    return best

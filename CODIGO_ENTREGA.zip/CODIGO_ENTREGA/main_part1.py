import os
import time
import random
import csv
from structure import instance
from algorithms import grasp

def medir_tiempo_grasp(instances_folder, output_file, alpha=0.1, iters=50):
    resultados = []
    tiempos = []

    for filename in os.listdir(instances_folder):
        if filename.endswith(".txt"):
            path = os.path.join(instances_folder, filename)
            print(f"\nEjecutando GRASP sobre {filename} ({iters} iteraciones)...")
            inst = instance.readInstance(path)

            start = time.time()
            best_val = -1
            for _ in range(iters):
                sol = grasp.execute(inst, 1, alpha)
                if sol['of'] > best_val:
                    best_val = sol['of']
            end = time.time()


            tiempo_total = end - start
            tiempo_medio = tiempo_total / iters
            tiempos.append(tiempo_medio)

            resultados.append([filename, f"{tiempo_total:.2f}", f"{tiempo_medio:.4f}", f"{best_val:.2f}"])
            print(f" → Tiempo total: {tiempo_total:.2f}s | Tiempo medio: {tiempo_medio:.2f}s")

    # Guardar CSV
    with open(output_file, mode="w", newline="", encoding="utf-8") as f_out:
        writer = csv.writer(f_out, delimiter=';')
        writer.writerow(["Instancia", "Tiempo total (s)", "Tiempo medio por iteración (s)", "Mejor valor"])
        writer.writerows(resultados)

    # Mostrar promedio global
    media_global = sum(tiempos) / len(tiempos)
    print(f"\n Tiempo medio global por iteración (GRASP): {media_global:.2f} segundos")
    return media_global

if __name__ == '__main__':
    random.seed(1)
    tiempo_medio_global = medir_tiempo_grasp("instances", "Resultados_GRASP_puro.csv", alpha=0.1, iters=50)

import os
import csv
import random
from structure import instance, solution
from algorithms import grasp

def generar_csv_valor_nodos(instances_folder, output_file, iteraciones=50, alpha=0.1):
    resultados = []

    # Cabecera dinámica: Iter 1 Valor, Iter 1 Nodos, Iter 2 Valor, ...
    header = ["Instancia"]
    for i in range(1, iteraciones + 1):
        header.append(f"Iter {i} Valor")
        header.append(f"Iter {i} Nodos")

    for filename in os.listdir(instances_folder):
        if filename.endswith(".txt"):
            print(f"\nEjecutando {iteraciones} GRASP para {filename}")
            path = os.path.join(instances_folder, filename)
            inst = instance.readInstance(path)

            fila = [filename]
            for i in range(iteraciones):
                sol = grasp.execute(inst, 1, alpha)
                valor = round(sol['of'], 2)
                nodos = " ".join(map(str, sorted(sol['sol'])))
                fila.extend([valor, nodos])
                print(f" Iter {i+1}: {valor}")

            resultados.append(fila)

    # Guardar CSV
    with open(output_file, mode="w", newline='', encoding="utf-8") as f_out:
        writer = csv.writer(f_out, delimiter=';')
        writer.writerow(header)
        writer.writerows(resultados)

    print(f"\nCSV generado correctamente: {output_file}")

if __name__ == '__main__':
    random.seed(1)
    generar_csv_valor_nodos("instances", "soluciones_50xInstancia.csv")

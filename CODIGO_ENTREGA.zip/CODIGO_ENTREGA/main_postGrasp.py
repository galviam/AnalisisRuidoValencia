import pandas as pd
import time
from structure import instance, solution
from pathrelinking.pathrelinking import path_relinking

# -------------------------------
# CONFIGURACIÓN
# -------------------------------
CSV_TIEMPOS_GRASP = "resultados_GRASP_puro.csv"
TIEMPO_EXTRA = 60 

def cargar_sol(inst, valor_str, nodos_str):
    sol = solution.createEmptySolution(inst)
    sol['of'] = float(str(valor_str).replace(',', '.'))
    sol['sol'] = set(map(int, nodos_str.strip().split()))
    return sol

def ejecutar_pathrelinking_controlado(path_excel, folder_instancias, path_salida_csv):
    df = pd.read_excel(path_excel)
    df_tiempos = pd.read_csv(CSV_TIEMPOS_GRASP, sep=';')
    df_tiempos['Instancia'] = df_tiempos['Instancia'].str.strip()
    df_tiempos['Tiempo medio por iteración (s)'] = pd.to_numeric(df_tiempos['Tiempo medio por iteración (s)'], errors='coerce')

    resultados = []

    for idx, row in df.iterrows():
        nombre = str(row.iloc[0]).strip().replace(",", ".")
        ruta_instancia = f"{folder_instancias}/{nombre}"
        inst = instance.readInstance(ruta_instancia)

        # Tiempo máximo permitido
        t_medio_grasp = df_tiempos.loc[df_tiempos['Instancia'] == nombre, 'Tiempo medio por iteración (s)'].values[0]
        tiempo_max = t_medio_grasp * 50 + TIEMPO_EXTRA

        print(f"\n>>> Instancia: {nombre}")
        print(f"Tiempo máximo para GRASP+PR: {tiempo_max:.2f}s")

        start = time.time()

        # Cargar soluciones
        s0 = cargar_sol(inst, row.iloc[1], row.iloc[2])
        s1 = cargar_sol(inst, row.iloc[3], row.iloc[4])
        s2 = cargar_sol(inst, row.iloc[5], row.iloc[6])
        s3 = cargar_sol(inst, row.iloc[7], row.iloc[8])

        intermedias = []

        for si, nombre_peor in zip([s1, s2, s3], ["PEOR 1", "PEOR 2", "PEOR 3"]):
            now = time.time()
            if now - start >= tiempo_max:
                print(f" Límite de tiempo alcanzado, se detiene PR")
                break
            pr = path_relinking(s0, si)
            intermedias.append(pr)
            print(f"  PR hacia {nombre_peor}: {round(pr['of'], 2)}")

        finalistas = [s0] + intermedias
        mejor_final = max(finalistas, key=lambda s: s['of'])

        end = time.time()
        tiempo_total = round(end - start, 4)

        print(">>> Mejor tras PR:")
        solution.printSolution(mejor_final)

        nodos_str = " ".join(map(str, sorted(mejor_final['sol'])))
        resultados.append([nombre, round(mejor_final['of'], 2), nodos_str, tiempo_total])

    # Guardar resultados
    pd.DataFrame(resultados, columns=["Instancia", "Valor Objetivo Final", "Nodos", "Tiempo (s)"]).to_csv(
        path_salida_csv, sep=';', index=False, encoding="utf-8"
    )
    print(f"\n Resultados guardados en: {path_salida_csv}")

# -------------------------------
# EJECUCIÓN
# -------------------------------
if __name__ == '__main__':
    ejecutar_pathrelinking_controlado(
        "MEJOR_SOL_GRASP.xlsx",
        "instances",
        "resultados_grasp_con_pr.csv"
    )

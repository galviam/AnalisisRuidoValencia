import os
import time
import random
import csv
from structure import instance
from algorithms import grasp

def tablaCalibracionCSV_Europeo(instances_folder, output_file, alphas, iters_por_alpha):
    with open(output_file, mode="w", newline='', encoding="utf-8") as f_out:
        writer = csv.writer(f_out, delimiter=';')

        # Cabecera
        header = ["Instancia"]
        for a in alphas:
            header.append(f"Alpha={a:.1f}_Valor")
            header.append(f"Alpha={a:.1f}_Tiempo")
        header.append("Mejor")
        writer.writerow(header)

        # Procesar instancias
        for filename in os.listdir(instances_folder):
            if filename.endswith(".txt"):
                path = os.path.join(instances_folder, filename)
                print(f"\nEjecutando {filename}")
                inst = instance.readInstance(path)

                fila = [filename]
                mejores_valores = []

                for alpha in alphas:
                    valores = []
                    start = time.time()
                    for _ in range(iters_por_alpha):
                        sol = grasp.execute(inst, 1, alpha)
                        valores.append(sol['of'])
                    end = time.time()
                    mejor_alpha = max(valores)
                    tiempo_alpha = end - start

                    # Formatear con coma como separador decimal
                    fila.append(f"{mejor_alpha:.2f}".replace(".", ","))
                    fila.append(f"{tiempo_alpha:.2f}".replace(".", ","))
                    mejores_valores.append(mejor_alpha)

                fila.append(f"{max(mejores_valores):.2f}".replace(".", ","))
                writer.writerow(fila)

        print(f"\n✅ Archivo CSV (europeo) generado: {output_file}")

if __name__ == '__main__':
    random.seed(1)
    alphas = [0.1]
    tablaCalibracionCSV_Europeo("instances", "resultados_alpha_tiempo1s.csv", alphas, iters_por_alpha=10)

var body = document.querySelector('body');
if (body) {
  function onSidebarCollapse() {
    var spanElement = document.querySelector('.logo');
    spanElement.innerHTML = '<i class="fa-brands fa-r-project"></i>'; // FontAwesome
  }
  function onSidebarExpand() {
    var spanElement = document.querySelector('.logo');
    spanElement.innerHTML = '<i class="fa-brands fa-r-project"></i> MiniProyecto';
  }

  var observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      if (mutation.attributeName === 'class') {
        var classList = mutation.target.classList;
        if (classList.contains('sidebar-collapse')) {
          onSidebarCollapse();
        } else {
          onSidebarExpand();
        }
      }
    });
  });
  var config = { attributes: true };
  observer.observe(body, config);
} else {
  console.log("No se pudo encontrar el elemento del cuerpo (body).");
}

//SELECCTING MENU
function controlarDivs() {

  var divs = document.querySelectorAll('div[id^="shiny-tab"]');

  divs.forEach(function (div) {
    if (div.classList.contains('active')) {
      var divId = div.id;
      var activeLink = document.querySelector('a[href="#' + divId + '"]');
      var menuIcons = document.querySelectorAll('.sidebar-menu i');


      menuIcons.forEach(function (icon) {
        if (icon.parentElement.href.split('#')[1] == activeLink.href.split('#')[1]) {
          icon.classList.add('fa-beat');
          if (icon.parentElement.parentElement.parentElement.classList.contains("treeview-menu")) {
            icon.parentElement.parentElement.parentElement.parentElement.firstElementChild.firstElementChild.classList.add('fa-beat');
          }

        } else {
          icon.classList.remove('fa-beat');
        }
      });
    }
  });
}


// Seleccionar el elemento padre que contiene los divs

function beatingLogo() {
  var contenedor = document.querySelector('.tab-content');
  if (contenedor) {
    // Crear una instancia de MutationObserver
    var observer = new MutationObserver(function (mutations) {
      // Iterar a través de las mutaciones observadas
      mutations.forEach(function (mutation) {
        // Verificar si la mutación es una adición de clase 'active' a un div
        if (mutation.type === 'attributes' && mutation.attributeName === 'class' && mutation.target.classList.contains('active')) {
          // Llamar a la función controlarDivs()
          controlarDivs();
        }
      });
    });

    // Configurar las opciones del observador
    var opciones = {
      attributes: true, // Observar cambios en los atributos
      attributeFilter: ['class'], // Observar cambios solo en el atributo 'class'
      subtree: true // Observar cambios en los nodos hijos también
    };

    // Comenzar a observar el contenedor
    observer.observe(contenedor, opciones);
  } else {
    console.log("NO hay contenedor")
  }

}



// Llamamos a la función cuando se carga la página
window.addEventListener('load', controlarDivs);
window.addEventListener('load', beatingLogo);


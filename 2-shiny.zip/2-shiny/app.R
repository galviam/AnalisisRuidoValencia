packages=c("shiny",
           "shinydashboard", 
           "shinydashboardPlus", 
           "shinyWidgets", 
           "leaflet", 
           "dplyr", 
           "sf", 
           "raster",
           "readr",
           "tidyr",
           "ggplot2",
           "lubridate",
           "magrittr",
           "plotly",
           "stringr",
           "showtext")

package.check <- lapply(packages, FUN=function(x) {
  if (!require(x, character.only=TRUE)) {
    install.packages(x, dependencies=TRUE,repos='http://cran.rediris.es')
    library(x, character.only=TRUE)
  }
})

# VARIABLES GLOBALES
TIPO_CONT = c("NO","NO2","NOx","SO2","O3")

#FUENTES
font_add("Montserrat", regular = "./www/Montserrat-Regular.ttf")

#FUNCIONES
quitar_espacios = function(vec){
  lista = c()
  for (x in vec){
    lista = rbind(lista,paste(substring(x,1,nchar(x)-4),substring(x,nchar(x)-2,nchar(x)),sep = ''))
  }
  return(lista)
}

# IMPORTACIÓN

### Datos de coches
data_imd = read_csv2("../data/idm.csv")
colnames(data_imd)[9] = "Ano"
data_imd = data_imd %>% 
  mutate(IMD = quitar_espacios(IMD)) %>% 
  mutate(IMD = as.numeric(IMD))

### Datos georeferenciados con todas las variables
geo_data = read_csv("../data/Geo_data.csv")

### Datos del muestreo
valor_SO2 = read_csv("../1-qgis/Mapa2/SO2/muestreado.csv")
valor_NO = read_csv("../1-qgis/Mapa2/NO/muestreado.csv")
valor_O3 = read_csv("../1-qgis/Mapa2/O3/muestreado.csv")
valor_NOx = read_csv("../1-qgis/Mapa2/NOx/muestreado.csv")
valor_NO2 = read_csv("../1-qgis/Mapa2/NO2/muestreado.csv")

valor_SO2$param = "SO2"
valor_NO$param = "NO"
valor_NO2$param = "NO2"
valor_NOx$param = "NOx"
valor_O3$param = "O3"

colnames(valor_SO2)[4] = "valor"
colnames(valor_NO)[4] = "valor"
colnames(valor_NO2)[4] = "valor"
colnames(valor_NOx)[4] = "valor"
colnames(valor_O3)[4] = "valor"

muestreado = rbind(valor_SO2,valor_NO,valor_NO2,valor_NOx,valor_O3) %>% 
  select(-field_1)

### Datos mapas
buffers = list()
parques = st_read('../1-qgis/datos_fijos/parques_urbanos.shp') %>% st_transform(4326)
interpolacion = raster('../1-qgis/datos_fijos/Interpolacion_imd.tif') %>%  projectRaster(crs=4326)
markers = list()
buffers_relacion = list()
for(medida in TIPO_CONT){
  buffers[[medida]] = st_read(paste('../1-qgis/Mapa1/',medida,'/buffer.shp',sep="")) %>% st_transform(4326)
  markers[[medida]] = read_csv(paste('../1-qgis/Mapa1/',medida,'/',medida,'.csv',sep=""))
  buffers_relacion[[medida]] = st_read(paste('../1-qgis/Mapa2/',medida,'/buffer_relacion.shp',sep="")) %>% st_transform(4326)
}

# ICONOS
iconoSensor = makeIcon(
  iconUrl = "./www/tower-cell-solid.svg",
  iconWidth = 20, iconHeight = 20,
  iconAnchorX = 0, iconAnchorY = 0
)

#Paletas
pal_inter = colorNumeric(palette=c("#000000","#ffffff"),values(interpolacion),na.color = "transparent")

###################

ui <- dashboardPage(
  #Añadimos lo que es similar a un theme en una fluidPage
  skin = "midnight", 
  
  #Hacemos las importaciones del css y el js
  tags$head(
    includeCSS("www/styles.css"),
    tags$body(tags$script(src = "funciones.js")),
    
    ),
  
  #Ponemos el título
  header = dashboardHeader(
    title = 'MiniProyecto'
    ),
  
  #Definimos el sidebar
  sidebar = dashboardSidebar(
    sidebarMenu(id="sidebar",
                #Aquí definimos cada elemento del sidebar, con su tabName para poder referenciarlo después y su icono
                #Dentro de alguno ponemos subItems que se abrirán al pulsarle
                #Hay algunos textos que están dentro de un HTML, esto es para poner <br>, que es un salto de línea. Ya que sino se corta el texto.
                
                menuItem("Inicio",tabName="inicio", icon = icon("lightbulb")),
                menuItem("Mapas", icon = icon("map-location-dot"),
                         menuSubItem(HTML("Contaminación e<br>IMD en Valencia"), tabName = "mapa1",icon = icon("layer-group")),
                         menuSubItem(HTML("Relación IMD <br>y contaminación"), tabName = "mapa2",icon = icon("layer-group"))),
                menuItem("Gráficos", icon = icon("chart-line"),
                         menuSubItem(HTML("Evolución de<br>la contaminación"), tabName = "temaGra1",icon = icon("magnifying-glass-chart")),
                         menuSubItem("Evolución del tráfico", tabName = "temaGra2",icon = icon("magnifying-glass-chart")),
                         menuSubItem("Evolución conjunta", tabName = "temaGra3",icon = icon("magnifying-glass-chart")),
                         menuSubItem(HTML("Relación tráfico<br>contaminación"), tabName = "temaGra4",icon = icon("magnifying-glass-chart"))),
                menuItem("Nosotros",tabName="aboutus", icon = icon("users-between-lines")),
                menuItem("Conclusiones",tabName="conc", icon = icon("circle-question"))
    )
  ),

  #Gefinimos el body
  
  body = dashboardBody(
    
    #Dentro de tabItems vamos a poner cada uno de los tabItem tiene que haber uno por cada tabName que hemos puesto en el menú.
    #Cuando se pulse al elemento del menú se mostrará en el body la información del tabItem con ese tabName.
    tabItems(
      tabItem(tabName = "inicio", 
              fluidRow(
                #Introducimos en una columna de tamaño 4 una instrucción HTML que carga un preview del pdf.
                column(4,HTML('<embed id="memoria" src="memoria.pdf" type="application/pdf">')
                       ),
                
                #Introducimos en una columna de tamaño 8 dos instrucciones HTML, una muestra el texto introductorio, la otra carga un preview del video.
                column(8,
                    HTML('<p style="text-align: left;font-size: large;">Este proyecto nace con la intención de relacionar al tráfico y la contaminación en Valencia. Para medir la contaminación utilizamos los datos de emisiones contaminantes recabados en diversas estaciones repartidas por la ciudad y para medir el tráfico usamos la Intensidad Media Diaria (IMD). Ya con estos datos buscaremos la posible relación que guarden entre sí. <br><br>Además, una de las conclusiones que se busca extraer es ver cómo afecta la presencia de los parques urbanos a la contaminación y al tráfico.  Si en zonas con parques urbanos la contaminación o el tráfico son elevados podremos afirmar que estos parques no se están cuidando como deberían. Con este proyecto se busca extraer conclusiones claras acerca de estos temas, con el objetivo de mostrar a la gente un problema patente que está pasando desapercibido.<br><br><p>'),
                    HTML('<video id="video" controls><source src="video.mp4" type="video/mp4">Your browser does not support the video tag.</video>')
                )
              )
              
      ),
      
      #A partir de aquí todos los tabItem (menos el último) siguen la misma distribución, por lo que explicamos esta y el resto son similares      

      tabItem(tabName = "mapa1",
              #Se muestra el mapa en leaflet, esto hace referencia al server en output$Mapa1, el mapa ocupará todo el ancho y 79 rem.
              #rem es una unidad de medida que hace referencia al tamaño de la letra
              
              leafletOutput("Mapa1",width = "100%", height = "79rem"),
              
              #Se introduce un título de tamaño h2 y en negrita.
              h2(strong("Contaminación e IMD en Valencia:")),
              
              #Aquí ponemos un texto explicativo, lo ponemos dentro de un HTML para poder modificar el estilo.
              HTML('<p style="font-size: large;">Este mapa muestra los datos de contaminación de un gas (NO, NO2, NOx, O3, SO2) recogidos en diversas estaciones. Esto lo realiza con los markers (que tienen un popup con el valor medio de dicha estación), y con los buffers, que de manera visual muestran un área afectada con un color en función de la cantidad de contaminación. Asimismo, el mapa muestra una intepolación del IMD (Intensidad Media Diaria), una medida de cuanto tráfico hay en diversas zonas. Finalmente, también se muestran los parques urbanos en verde. Este mapa nos permite ver si hay alguna relación entre la contaminación de los gases mencionados y la cantidad de tráfico. Además, fijándonos en los parques urbanos podemos ver si la cercanía a estos hace que haya menor contaminación o tráfico. De no ser asi, quizás habría que replantearse si se estan dañando estos parques urbanos, y buscar soluciones para reducir el tráfico y la contaminación en sus alrededores.<p>'),              
              
              #Queremos introducir un dropdownButton, pero para poder posicionarlo donde queramos lo ponemos en un div
              tags$div(
                
                #Añadimos la posición donde queremos verlo
                style="position: absolute;right: 2%;top: 8%;",
                
                #Definimos lo que habrá dentro del dropdownButton: todos los inputs, y las caraterísticas
                dropdownButton(
                  h3("Lista de entradas"),
                  selectInput("tipo_cont_mapa1",label="Selecciona el tipo de contaminación:",choices=TIPO_CONT,selected="NO"),
                  h5("Selecciona los elementos a visualizar:"),
                  
                  #Este es un tipo especial de input de la librería shinyWidgets, funciona como un checkbox, pero es más estético.
                  switchInput("buffer_m1",label = "Buffers",value=TRUE),
                  switchInput("parque_m1",label = "Parques",value=TRUE),
                  switchInput("inter_m1",label = "Interpolación",value=TRUE),
                  sliderInput("opac_buff_mapa1",label="Selecciona la opacidad de los buffers:",min=0,max=1,step = 0.05,value=0.7) ,         
                  sliderInput("opac_inter_mapa1",label="Selecciona la opacidad de la interpolación:",min=0,max=1,step = 0.05,value=0.6),
                  actionButton("btn_m1","Aplicar Cambios"),
                  
                  #Hace que no se salga por la derecha si no hay espacio en la pantalla
                  right = TRUE,
                  #Hace que el texto salga del botón
                  inline = TRUE,
                  #Define el color
                  status = "danger",
                  #Ponemos la forma
                  icon = icon("gear"), 
                  #Ponemos el tamaño
                  width = "300px"
                )
              )
        
      ),
      tabItem(tabName = "mapa2", 
              leafletOutput("Mapa2",width = "100%", height = "79rem"),
              h2(strong("Relación IMD y contaminación:")),
              HTML('<p style="font-size: large;">Este mapa muestra la relación entre el IMD y la contaminación de un gas (NO, NO2, NOx, O3, SO2). La relación está establecida como IMD/Contaminación, por lo que a mayor valor de la relación, es menor la cantidad de contaminación explicable por la cantidad de tráfico. Esto se representa con buffers situados en las estaciones, variando su color en función de como varia la relación. Esto nos permite ver si en zonas cercanas a los parques urbanos la contaminación se debe al tráfico o hay factores externos.<p>'),              
              
              
              tags$div(
                style="position: absolute;right: 2%;top: 8%;",
                dropdownButton(
                  tags$h3("Lista de entradas"),
                  selectInput("tipo_cont_mapa2",label="Selecciona el tipo de contaminación:",choices=TIPO_CONT,selected="NO"),
                  h5("Selecciona los elementos a visualizar:",value=TRUE),
                  switchInput("buffer_m2",label = "Buffers",value=TRUE),
                  switchInput("parque_m2",label = "Parques",value=TRUE),
                  sliderInput("opac_buff_mapa2",label="Selecciona la opacidad de los buffers:",min=0,max=1,step = 0.05,value=0.7) ,         
                  actionButton("btn_m2","Aplicar Cambios"),
                  
                  
                  right = TRUE,
                  inline=TRUE,
                  status = "danger",
                  icon = icon("gear"), 
                  width = "300px"
                )
              )
      ),
    
    tabItem(tabName = "temaGra1", 
            plotlyOutput("Grafico1",width = "100%", height = "79rem"),
            HTML('<p style="font-size: large;">Aquí podemos ver como evoluciona la contaminación. Como se puede ver los nitratos (NO, NO2, NOx) siguen una misma tendencia. Lo que significa que (muy probablemente) tengan una fuente de emisión común.<br>También se observa una clara tendencia a la baja, probablemente sea por las medidas que se están aplicando últimamente para intentar reducir las emisiones de todo aparato que emita cualquier tipo de contaminación.<br>Por último se puede ver como los fines de semana se ve reducida la cantidad de polución.<p>'),              
            tags$div(
              style="position: absolute;right: 2%;top: 80%;",
              dropdownButton(
                tags$h3("Lista de entradas"),
                selectInput("tiempo_g1",
                            label="Selecciona en función de que tiempo quieres ver el gráfico:",
                            choices=c("Año" = "ano","Mes"="mes", "Día del mes" = "dia_mes", "Día de la semana" = "dia_semana"), 
                            selected = "ano"),
                selectInput("medida_g1",
                            label="Selecciona la medida por la que visualizar:",
                            choices=c("Estación" = "estacion","Parámetro de contaminación"="param"), 
                            selected = "param"),
                uiOutput("input_g1"),
                actionButton("btn_g1","Calcular"),
                right = TRUE,
                up = TRUE,
                inline=TRUE,
                status = "danger",
                icon = icon("gear"), 
                width = "300px"
              )
            ),
            ),
    tabItem(tabName = "temaGra2", 
            plotlyOutput("Grafico2",width = "100%", height = "79rem"),
            HTML('<p style="font-size: large;">Como podemos ver este gráfico se trata de la evolución del tráfico, y cómo se distribuye en función de las zonas. Se observa que la distribución del tráfico es uniforme, tuvo un bajón (como es lógico) durante la pandemia, a pesar de ello el tráfico no ha vuelto a los niveles de antes, esto puede suponer una tendencia y que no vuelva a los niveles normales.<bt>También se ve como los meses de agosto son calaramente los meses que menos contaminación hay, probablemente por las vacaciones, que la ciudad se queda vacía y se llena de turistas, que no circulan tanto en coche.<p>'),              
            
            tags$div(
              style="position: absolute;right: 2%;top: 80%;",
              dropdownButton(
                tags$h3("Lista de entradas"),
                selectInput("tiempo_g2",
                            label="Selecciona en función de que tiempo quieres ver el gráfico:",
                            choices=c("Año" = "ano","Mes"="mes"), 
                            selected = "ano"),
                checkboxGroupInput("area_coches_g2",
                                   label="Selecciona las áreas a estudiar:",
                                   choices=unique(data_imd$`Tipo dato`), 
                                   selected = unique(data_imd$`Tipo dato`)),
                
                
                right = TRUE,
                up = TRUE,
                inline=TRUE,
                status = "danger",
                icon = icon("gear"),
                width = "300px"
              )
            ),
            ),
    tabItem(tabName = "temaGra3", 
            fluidRow(plotlyOutput("Grafico3_1",width = "95%")),
            fluidRow(plotlyOutput("Grafico3_2",width = "95%")),
            HTML('<p style="font-size: large;">Este gráfico aúna los dos gráficas anteriores para hacer la comparación más sencilla, gracias a esto podemos ver que hay relación entre los datos de contaminación de los nitratos (NO/NOx/NO2), y el tráfico de hecho, los máximos y los mínimos (sobre todo los mínimos) se encuentran muy cercanos. Por ello podemos afirmar que los coches emiten este tipo de contaminantes, lo cual si se hace una búsqueda en internet se puede ver que es cierto.<p>'),              
            
            tags$div(
              style="position: absolute;right: 2%;top: 80%;",
              dropdownButton(
                tags$h3("Lista de entradas"),
                selectInput("tiempo_g3",
                            label="Selecciona en función de que tiempo quieres ver el gráfico:",
                            choices=c("Año" = "ano","Mes"="mes"), 
                            selected = "ano"),
                
                right = TRUE,
                up = TRUE,
                inline=TRUE,
                status = "danger",
                icon = icon("gear"), 
                width = "300px"
              )
            )
            ),
    tabItem(tabName = "temaGra4", 
            plotlyOutput("Grafico4", height = "79rem"),
            HTML('<p style="font-size: large;">En este gráfico podemos ver las relaciones entre las medidas de contaminación y la cantidad de tráfico, y un ajuste lineal de los datos.<br>Como podemos ver si una calle tiene de media más tráfico no se puede afirmar que tenga de media más contaminación.<p>')),   
    
    tabItem(tabName = "aboutus", 
            
        #Aquí vamos a hacer una descripción de cada persona, cada dos personas van a formar un fila.
        #Vamos a usar userBox, que es una función de shinydashboardplus, que permite poner unas cards con nuestros nombres, una foto y una pequeña descrpción.
        fluidRow(
            userBox(
              title = userDescription(
                title = "Javier Martínez",
                type = 2,
                image="javii.jpg"
              ),
              background = "navy",
              descriptionBlock(h4(em("\"Data dcientist and front-end developer. Experienced in coding with HTML, Javascript, CSS, Bootstrap, Python, SQL and R. Interested in AI and neural networks\"",style="color:white !important")))
              
            ),
            userBox(
              
              title = userDescription(
                title = "Pedro de Luna",
                type = 2,
                image="pedro.jpg"
              ),
            
              background = "orange",
              descriptionBlock(h4(em("\"Data Scientist and Back-end. Have been working with C#, Git, Docker, Python, SQL and R. I relentlessly pursue my goals, ensuring efficiency in every task I undertake.\"",style="color:white !important")))
              
              
            )
            ),
        fluidRow(
            userBox(
              title = userDescription(
                title = "Antonio Hernando",
                type = 2,
                image="toni.jpg"
              ),
              background = "aqua",
              descriptionBlock(h4(em("\"Excellent communicator of analytical results, converting data into clear and compelling stories (datastorytelling). \"",style="color:white !important")))
              
              
              
            ),
            userBox(
              
              title = userDescription(
                title = "Lucia Carro",
                type = 2,
                image="lucia.jpg"),
              background = "light-blue",
              descriptionBlock(h4(em("\"Data analyst with a strong technical background and experience in challenging projects \"",style="color:white !important")))
              
              
            ),
        ),
        fluidRow(
            userBox(
              
              title = userDescription(
                title = "Lidia Moreno",
                type = 2,
                image="lidia.jpg"),
              background = "olive",
              descriptionBlock(h4(em("\"Proactive collaborator, adaptable and capable of delivering high-quality results in dynamic environments \"",style="color:white !important")))
              
              
            ),
            userBox(
              title = userDescription(
                title = "Amparo Gálvez",
                type = 2,
                image="amparo.jpg"),
              background = "fuchsia",
              descriptionBlock(h4(em("\"I stand out for my initiative and ability to take the lead in various activities, showcasing my leadership capabilities. \"",style="color:white !important")))
              
            )
        )
            
    ),
    tabItem(tabName = "conc",h1(strong("Conclusiones finales")),
    h3("A pesar de que la lógica nos dice que a mayor cantidad de coches sí o sí debería
haber más contaminación con los datos que hemos obtenido no podemos
afirmar tajantemente que haya una relación. Es muy probable que exista dicha
relación, pero con los datos que nos ha facilitado la Generalitat no podemos
afirmarlo.
A pesar de ello, sí que podemos decir que la contaminación es un fenómeno
multifactorial y que no depende únicamente de los coches.
También hemos visto como las medidas puntuales carecen bastante de sentido.
Por ejemplo, si por esta calle no pasa ningún coche pero por la de al lado no paran
de pasar la contaminación en esta calle será más alta de lo que debería. Dado que
los contaminantes se mueven por el aire tiene bastante sentido hacer la
comparación por tiempo y no por localización, como se ha visto en el mapa tres,
donde se ha visto que existe una mayor relación")) 
    )

  ),
  #Estos elementos pertenecen al dashboardPage, dado que no los hemos usado los hemos dejado en NULL, para que no se muestren.
  controlbar = NULL,
  footer = NULL
)


server <- function(input, output) {
  #renderUI
  output$input_g1 = renderUI({
    #En función de la medida que se quiera hacer queremos cargar una choices y un texto en el checkboxGroupInput
    if(input$medida_g1 == "param"){
      return(checkboxGroupInput("parametros_g1",
                                label="Selecciona las áreas a estudiar:",
                                choices=TIPO_CONT, 
                                selected=TIPO_CONT))
    }else{
      return(checkboxGroupInput("estaciones_g1",
                                label="Selecciona las estaciones a estudiar:",
                                choices=unique(geo_data$Estacion), 
                                selected=unique(geo_data$Estacion)))
    }
  })
  
  #Mapas
  ##Mapa 1
  output$Mapa1 <- renderLeaflet({
    return (funcionMapa1())
  })
  ##Mapa 2
  output$Mapa2 <- renderLeaflet({
    return (funcionMapa2())
  })
  
  #Graficos
  ##Gráfico 1
  output$Grafico1 = renderPlotly({
    return(funcionGrafico1())
  })
  
  ##Gráfico 2
  output$Grafico2 = renderPlotly({
    return(funcionGrafico2())
  })  
  
  ##Gráficos 3
  output$Grafico3_1 = renderPlotly({
    return(funcionGrafico3_1())
  })
  output$Grafico3_2 = renderPlotly({
    return(funcionGrafico3_2())
  })
  
  ##Gráfico 4
  output$Grafico4 = renderPlotly({
    return(funcionGrafico4())
  })
  
  
  #Funciones
  
  ##Mapas
  funcionMapa1 = eventReactive(c(input$btn_m1),{
    medida= input$tipo_cont_mapa1
    
    # VARIABLES
    varBuffer = colnames(buffers[[medida]])[which(grepl(medida,colnames(buffers[[medida]])) == TRUE)[length(which(grepl(medida,colnames(buffers[[medida]])) == TRUE))]]
    valoresBuffer =  eval(parse(text=paste("buffers[[medida]]$",varBuffer,sep="")))
    valoresMarkers = round(eval(parse(text=paste("markers[[medida]]$",medida,sep=""))),3)
    
    # PALETAS
    pal_buffer = colorNumeric(palette=c("#ffff00","#ff8000","#ff0000"),domain= valoresBuffer)
    
    # MAPA
    mapa = leaflet(options = leafletOptions(minZoom = 10, maxZoom = 20)) %>% 
      addTiles() %>% #addProviderTiles(provider = providers$ELQUESEA)
      setView(lng = -0.37739, lat = 39.46975, zoom = 13) %>% 
      
      # MARKERS
      addMarkers(lng = markers[[medida]]$lon, lat = markers[[medida]]$lat,
                 popup = as.character(valoresMarkers),
                 icon = iconoSensor) 
    
    
    # PARQUES
    if (input$parque_m1){
      mapa = mapa  %>% addPolygons(data = parques, 
                                   color= "transparent", 
                                   fillColor = "green", 
                                   fillOpacity = 1)
    }
    
    
    # INTERPOLACION
    if (input$inter_m1){
      mapa = mapa  %>% addRasterImage(interpolacion,
                                      colors = pal_inter,
                                      opacity = as.character(input$opac_inter_mapa1)) %>%
        addLegend("bottomleft",pal=pal_inter,
                  values=na.omit(values(interpolacion)),
                  title = "IMD de tráfico ")
    }
    
    
    # BUFFERS
    if (input$buffer_m1){
      mapa = mapa   %>% addPolygons(data = buffers[[medida]],
                                    color= "transparent",#black
                                    fillColor = pal_buffer(valoresBuffer),
                                    fillOpacity = input$opac_buff_mapa1) %>%
        
        addLegend("bottomleft",pal=pal_buffer,
                  values=valoresBuffer,
                  title = paste("Contaminación de ",medida,sep=""))
      
    }
    return(mapa)
    
  })
  
  funcionMapa2 = eventReactive(c(input$btn_m2),{
    medida= input$tipo_cont_mapa2
    
    # VARIABLES
    valoresBuffer = buffers_relacion[[medida]]$relacion
    
    
    # PALETAS
    pal_buffer = colorNumeric(palette=c("#ffff00","#ff8000","#ff0000"),domain= valoresBuffer)
    
    
    # MAPA
    mapa = leaflet(options = leafletOptions(minZoom = 10, maxZoom = 20)) %>% 
      addTiles() %>% #addProviderTiles(provider = providers$ELQUESEA)
      setView(lng = -0.37739, lat = 39.46975, zoom = 13) 
    
    
    
    
    # PARQUES
    if (input$parque_m2){
      mapa = mapa  %>% addPolygons(data = parques, 
                                   color= "transparent", 
                                   fillColor = "green", 
                                   fillOpacity = 1)
    }
    
    
    # BUFFERS
    if (input$buffer_m2){
      mapa = mapa   %>% addPolygons(data = buffers_relacion[[medida]],
                                    color= "transparent",#black
                                    fillColor = pal_buffer(valoresBuffer),
                                    fillOpacity = input$opac_buff_mapa2) %>%
        
        addLegend("bottomleft",pal=pal_buffer,
                  values=valoresBuffer,
                  title = paste("Relacion entre IMD y ",medida,sep=""))
      
    }
    
    return(mapa)
    
  })
  
  
  #Gráficos
  ## Si hay alguna duda sobre el funcionamiento de los gráficos mirar la memoria
  funcionGrafico1 = eventReactive(c(input$btn_g1),{
    #Si se acaba de abrir y no se ha pulsado al botón por defecto se quieren todos los parámetros
    if(input$btn_g1 == 0){
      parametros = TIPO_CONT
    }else{
      parametros = input$parametros_g1
    }
    
    #En funciónd e la medida y del tiempose hace uno u otro gráfico
    if(input$medida_g1 == "param"){
      if(input$tiempo_g1 == "ano"){
        graf = geo_data %>% 
          mutate(Fecha = ymd(Fecha)) %>% 
          mutate(tiempo = year(Fecha)) %>% 
          gather(c(NO,NO2,SO2,O3,NOx),key = "param", value = "valor") %>% 
          filter(is_in(param,parametros)) %>% 
          group_by(tiempo, param) %>% 
          drop_na() %>% 
          summarise(media = mean(valor)) %>% 
          ggplot(aes(x = tiempo, y = media, colour = param)) + 
          geom_line() + 
          labs(x = "", y = "Medida de polución", title = "Polución en función del año y del parámetro medido") + 
          theme(plot.background = element_rect(fill = "#353C42"),
                panel.background = element_rect(fill = "#353C42"),
                legend.background = element_rect(fill = "#353C42"),
                plot.title = element_text(colour = "white",hjust = 0.5, size = 20,family="Montserrat"),
                text = element_text(colour = "white",family="Montserrat"),
                axis.line = element_line(colour = "white",size = 2),
                panel.grid.major = element_line(color = "lightgrey", size = 0.5),
                panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
                axis.text = element_text(colour = "white",family="Montserrat"))+
          scale_x_continuous(n.breaks = 10)+
          scale_color_brewer(palette="Set1")
      }else if(input$tiempo_g1 == "mes"){
        graf = geo_data %>% 
          mutate(Fecha = ymd(Fecha)) %>% 
          mutate(tiempo = month(Fecha, label = T)) %>% 
          mutate(tiempo = factor(tiempo)) %>% 
          gather(c(NO,NO2,SO2,O3,NOx),key = "param", value = "valor") %>% 
          filter(is_in(param,parametros)) %>% 
          group_by(tiempo, param) %>% 
          drop_na() %>% 
          summarise(media = mean(valor)) %>% 
          ggplot(aes(x = tiempo, y = media, colour = param, group = param)) + 
          geom_line() + 
          labs(x = "", y = "Medida de polución", title = "Polución en función del mes y del parámetro medido")  + 
          theme(plot.background = element_rect(fill = "#353C42"),
                panel.background = element_rect(fill = "#353C42"),
                legend.background = element_rect(fill = "#353C42"),
                plot.title = element_text(colour = "white",hjust = 0.5, size = 20,family="Montserrat"),
                text = element_text(colour = "white",family="Montserrat"),
                axis.line = element_line(colour = "white",size = 2),
                panel.grid.major = element_line(color = "lightgrey", size = 0.5),
                panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
                axis.text = element_text(colour = "white",family="Montserrat"))+
          scale_color_brewer(palette="Set1")
      }else if(input$tiempo_g1 == "dia_mes"){
        graf = geo_data %>% 
          gather(c(NO,NO2,SO2,O3,NOx),key = "param", value = "valor") %>% 
          filter(is_in(param,parametros)) %>% 
          group_by(`Dia del mes`, param) %>% 
          drop_na() %>% 
          summarise(media = mean(valor)) %>% 
          ggplot(aes(x = `Dia del mes`, y = media, colour = param)) + 
          geom_line() + 
          labs(x = "", y = "Medida de polución", title = "Polución en función del día del mes y del parámetro medido")  + 
          theme(plot.background = element_rect(fill = "#353C42"),
                panel.background = element_rect(fill = "#353C42"),
                legend.background = element_rect(fill = "#353C42"),
                plot.title = element_text(colour = "white",hjust = 0.5, size = 20,family="Montserrat"),
                text = element_text(colour = "white",family="Montserrat"),
                axis.line = element_line(colour = "white",size = 2),
                panel.grid.major = element_line(color = "lightgrey", size = 0.5),
                panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
                axis.text = element_text(colour = "white",family="Montserrat"))+
          scale_x_continuous(n.breaks = 16)+
          scale_color_brewer(palette="Set1")
      }else{
        graf = geo_data %>% 
          mutate(Fecha = ymd(Fecha)) %>% 
          mutate(tiempo = wday(Fecha, label = T, abbr = FALSE, week_start = 1)) %>% 
          mutate(tiempo = factor(tiempo)) %>% 
          gather(c(NO,NO2,SO2,O3,NOx),key = "param", value = "valor") %>% 
          filter(is_in(param,parametros)) %>% 
          group_by(tiempo, param) %>% 
          drop_na() %>% 
          summarise(media = mean(valor)) %>% 
          ggplot(aes(x = tiempo, y = media, colour = param, group = param)) + 
          geom_line() + 
          labs(x = "", y = "Medida de polución", title = "Polución en función del día de la semana y del parámetro medido")     + 
          theme(plot.background = element_rect(fill = "#353C42"),
                panel.background = element_rect(fill = "#353C42"),
                legend.background = element_rect(fill = "#353C42"),
                plot.title = element_text(colour = "white",hjust = 0.5, size = 20,family="Montserrat"),
                text = element_text(colour = "white",family="Montserrat"),
                axis.line = element_line(colour = "white",size = 2),
                panel.grid.major = element_line(color = "lightgrey", size = 0.5),
                panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
                axis.text = element_text(colour = "white",family="Montserrat"))+
          scale_color_brewer(palette="Set1")
      }  
    }else if(input$medida_g1 == "estacion"){
      if(input$tiempo_g1 == "ano"){
        graf = geo_data %>% 
          mutate(Fecha = ymd(Fecha)) %>% 
          mutate(tiempo = year(Fecha)) %>% 
          gather(c(NO,NO2,SO2,O3,NOx),key = "param", value = "valor") %>% 
          filter(is_in(Estacion,input$estaciones_g1)) %>% 
          group_by(tiempo, Estacion) %>% 
          drop_na() %>% 
          summarise(media = mean(valor)) %>% 
          ggplot(aes(x = tiempo, y = media, colour = Estacion)) + 
          geom_line() + 
          labs(x = "", y = "Polución media", title = "Polución en función del año y de la estación") + 
          theme(plot.background = element_rect(fill = "#353C42"),
                panel.background = element_rect(fill = "#353C42"),
                legend.background = element_rect(fill = "#353C42"),
                plot.title = element_text(colour = "white",hjust = 0.5, size = 20,family="Montserrat"),
                text = element_text(colour = "white",family="Montserrat"),
                axis.line = element_line(colour = "white",size = 2),
                panel.grid.major = element_line(color = "lightgrey", size = 0.5),
                panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
                axis.text = element_text(colour = "white",family="Montserrat"))+
          scale_x_continuous(n.breaks = 10)+
          scale_color_brewer(palette="Set1")
      }else if(input$tiempo_g1 == "mes"){
        graf = geo_data %>% 
          mutate(Fecha = ymd(Fecha)) %>% 
          mutate(tiempo = month(Fecha,label = T)) %>% 
          gather(c(NO,NO2,SO2,O3,NOx),key = "param", value = "valor") %>% 
          filter(is_in(Estacion,input$estaciones_g1)) %>% 
          group_by(tiempo, Estacion) %>% 
          drop_na() %>% 
          summarise(media = mean(valor)) %>% 
          ggplot(aes(x = tiempo, y = media, colour = Estacion, group = Estacion)) + 
          geom_line() + 
          labs(x = "", y = "Polución media", title = "Polución en función del mes y de la estación") + 
          theme(plot.background = element_rect(fill = "#353C42"),
                panel.background = element_rect(fill = "#353C42"),
                legend.background = element_rect(fill = "#353C42"),
                plot.title = element_text(colour = "white",hjust = 0.5, size = 20,family="Montserrat"),
                text = element_text(colour = "white",family="Montserrat"),
                axis.line = element_line(colour = "white",size = 2),
                panel.grid.major = element_line(color = "lightgrey", size = 0.5),
                panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
                axis.text = element_text(colour = "white",family="Montserrat"))+
          scale_color_brewer(palette="Set1")
      }else if(input$tiempo_g1 == "dia_mes"){
        graf = geo_data %>% 
          gather(c(NO,NO2,SO2,O3,NOx),key = "param", value = "valor") %>% 
          filter(is_in(Estacion,input$estaciones_g1)) %>% 
          group_by(`Dia del mes`, Estacion) %>% 
          drop_na() %>% 
          summarise(media = mean(valor)) %>% 
          ggplot(aes(x = `Dia del mes`, y = media, colour = Estacion)) + 
          geom_line() + 
          labs(x = "", y = "Polución media", title = "Polución en función del día del mes y de la estación") + 
          theme(plot.background = element_rect(fill = "#353C42"),
                panel.background = element_rect(fill = "#353C42"),
                legend.background = element_rect(fill = "#353C42"),
                plot.title = element_text(colour = "white",hjust = 0.5, size = 20,family="Montserrat"),
                text = element_text(colour = "white",family="Montserrat"),
                axis.line = element_line(colour = "white",size = 2),
                panel.grid.major = element_line(color = "lightgrey", size = 0.5),
                panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
                axis.text = element_text(colour = "white",family="Montserrat"))+
          scale_x_continuous(n.breaks = 16)+
          scale_color_brewer(palette="Set1")
      }  else{
        graf = geo_data %>% 
          mutate(Fecha = ymd(Fecha)) %>% 
          mutate(tiempo = wday(Fecha,label = T, abbr = F, week_start = 1)) %>% 
          gather(c(NO,NO2,SO2,O3,NOx),key = "param", value = "valor") %>% 
          filter(is_in(Estacion,input$estaciones_g1)) %>% 
          group_by(tiempo, Estacion) %>% 
          drop_na() %>% 
          summarise(media = mean(valor)) %>% 
          ggplot(aes(x = tiempo, y = media, colour = Estacion, group = Estacion)) + 
          geom_line() + 
          labs(x = "", y = "Polución media", title = "Polución en función del día de la semana y de la estación") + 
          theme(plot.background = element_rect(fill = "#353C42"),
                panel.background = element_rect(fill = "#353C42"),
                legend.background = element_rect(fill = "#353C42"),
                plot.title = element_text(family="Montserrat",colour = "white",hjust = 0.5, size = 20),
                text = element_text(family="Montserrat",colour = "white"),
                axis.line = element_line(colour = "white",size = 2),
                panel.grid.major = element_line(color = "lightgrey", size = 0.5),
                panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
                axis.text = element_text(family="Montserrat",colour = "white"))+
          scale_color_brewer(palette="Set1")
      }
    }
    
    return(ggplotly(graf))
  })
  
  funcionGrafico2 = eventReactive(c(input$tiempo_g2, input$area_coches_g2),{
    if(input$tiempo_g2 == "ano"){
      graf = data_imd %>% 
        select(`Tipo dato`, IMD, Ano) %>% 
        filter(is_in(`Tipo dato`, input$area_coches_g2)) %>% 
        group_by(`Tipo dato`, Ano) %>% 
        drop_na() %>% 
        summarise(IMD = mean(IMD)) %>% 
        ggplot()+
        geom_line(aes(x = Ano, y = IMD, col = `Tipo dato`))+
        geom_point(aes(x = Ano, y = IMD, col = `Tipo dato`)) + 
        labs(x = "Año", y = "Intensidad media diaria", title = "Cantidad de coches en función de la zona por años") + 
        theme(plot.background = element_rect(fill = "#353C42"),
              panel.background = element_rect(fill = "#353C42"),
              legend.background = element_rect(fill = "#353C42"),
              plot.title = element_text(family="Montserrat",colour = "white",hjust = 0.5, size = 20),
              text = element_text(family="Montserrat",colour = "white"),
              axis.line = element_line(colour = "white",size = 2),
              panel.grid.major = element_line(color = "lightgrey", size = 0.5),
              panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
              axis.text = element_text(family="Montserrat",colour = "white"))+
        scale_x_continuous(n.breaks = 10)+
        scale_color_brewer(palette="Set1")
    }else{
      graf = data_imd %>% 
        select(`Tipo dato`, IMD, Mes) %>% 
        filter(is_in(`Tipo dato`, input$area_coches_g2)) %>% 
        mutate(Mes = factor(Mes, levels = c("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"))) %>% 
        group_by(`Tipo dato`, Mes) %>% 
        drop_na() %>% 
        summarise(IMD = mean(IMD)) %>% 
        ggplot(aes(x = Mes, y = IMD, col = `Tipo dato`, group = `Tipo dato`))+
        geom_line()+
        geom_point() + 
        labs(x = "Año", y = "Intensidad media diaria", title = "Cantidad de coches en función de la zona por meses") + 
        theme(plot.background = element_rect(fill = "#353C42"),
              panel.background = element_rect(fill = "#353C42"),
              legend.background = element_rect(fill = "#353C42"),
              plot.title = element_text(family="Montserrat",colour = "white",hjust = 0.5, size = 20),
              text = element_text(family="Montserrat",colour = "white"),
              axis.line = element_line(colour = "white",size = 2),
              panel.grid.major = element_line(color = "lightgrey", size = 0.5),
              panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
              axis.text = element_text(family="Montserrat",colour = "white"))+
        scale_color_brewer(palette="Set1")
    }
    
    return(ggplotly(graf))
  })
  
  funcionGrafico3_1 = eventReactive(input$tiempo_g3,{
    if(input$tiempo_g3 == "ano"){
      graf = geo_data %>% 
        mutate(Fecha = ymd(Fecha)) %>% 
        mutate(tiempo = year(Fecha)) %>% 
        gather(c(NO,NO2,SO2,O3,NOx),key = "param", value = "valor") %>% 
        group_by(tiempo, param) %>% 
        filter(tiempo >= min(data_imd$Ano,na.rm = T)) %>% 
        filter(tiempo <= max(data_imd$Ano,na.rm = T)) %>% 
        drop_na() %>% 
        summarise(media = mean(valor)) %>% 
        ggplot(aes(x = tiempo, y = media, colour = param)) + 
        geom_point()+
        geom_line() + 
        labs(x = "", y = "Medida de polución", title = "Polución en función del año y del parámetro medido") + 
        theme(plot.background = element_rect(fill = "#353C42"),
              panel.background = element_rect(fill = "#353C42"),
              legend.background = element_rect(fill = "#353C42"),
              plot.title = element_text(family="Montserrat",colour = "white",hjust = 0.5, size = 20),
              text = element_text(family="Montserrat",colour = "white"),
              axis.line = element_line(colour = "white",size = 2),
              panel.grid.major = element_line(color = "lightgrey", size = 0.5),
              panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
              axis.text = element_text(family="Montserrat",colour = "white"))+
        scale_x_continuous(n.breaks = 10)+
        scale_color_brewer(palette="Set1")
    }else{
      graf = geo_data %>% 
        mutate(Fecha = ymd(Fecha)) %>% 
        mutate(tiempo = str_to_title(month(Fecha, label = T, abbr = F))) %>% 
        mutate(tiempo = factor(tiempo, levels = c("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"))) %>% 
        gather(c(NO,NO2,SO2,O3,NOx),key = "param", value = "valor") %>% 
        group_by(tiempo, param) %>% 
        drop_na() %>% 
        summarise(media = mean(valor)) %>% 
        ggplot(aes(x = tiempo, y = media, colour = param, group = param)) + 
        geom_point() +
        geom_line() + 
        labs(x = "", y = "Medida de polución", title = "Polución en función del mes y del parámetro medido")  + 
        theme(plot.background = element_rect(fill = "#353C42"),
              panel.background = element_rect(fill = "#353C42"),
              legend.background = element_rect(fill = "#353C42"),
              plot.title = element_text(family="Montserrat",colour = "white",hjust = 0.5, size = 20),
              text = element_text(family="Montserrat",colour = "white"),
              axis.line = element_line(colour = "white",size = 2),
              panel.grid.major = element_line(color = "lightgrey", size = 0.5),
              panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
              axis.text = element_text(family="Montserrat",colour = "white"))+
        scale_color_brewer(palette="Set1")
    }
    
    return(ggplotly(graf))
  })
  
  funcionGrafico3_2 = eventReactive(input$tiempo_g3,{
    if(input$tiempo_g3 == "ano"){
      graf = data_imd %>% 
        select(`Tipo dato`, IMD, Ano) %>% 
        group_by(`Tipo dato`, Ano) %>% 
        drop_na() %>% 
        summarise(IMD = mean(IMD)) %>% 
        ggplot()+
        geom_line(aes(x = Ano, y = IMD, col = `Tipo dato`))+
        geom_point(aes(x = Ano, y = IMD, col = `Tipo dato`)) + 
        labs(x = "Año", y = "Intensidad media diaria", title = "Cantidad de coches en función de la zona por años") + 
        theme(plot.background = element_rect(fill = "#353C42"),
              panel.background = element_rect(fill = "#353C42"),
              legend.background = element_rect(fill = "#353C42"),
              plot.title = element_text(family="Montserrat",colour = "white",hjust = 0.5, size = 20),
              text = element_text(family="Montserrat",colour = "white"),
              axis.line = element_line(colour = "white",size = 2),
              panel.grid.major = element_line(color = "lightgrey", size = 0.5),
              panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
              axis.text = element_text(family="Montserrat",colour = "white"))+
        scale_x_continuous(n.breaks = 10)+
        scale_color_brewer(palette="Set1")
    }else{
      graf = data_imd %>% 
        select(`Tipo dato`, IMD, Mes) %>% 
        mutate(Mes = factor(Mes, levels = c("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"))) %>% 
        group_by(`Tipo dato`, Mes) %>% 
        drop_na() %>% 
        summarise(IMD = mean(IMD)) %>% 
        ggplot(aes(x = Mes, y = IMD, col = `Tipo dato`, group = `Tipo dato`))+
        geom_line()+
        geom_point() + 
        labs(x = "Mes", y = "Intensidad media diaria", title = "Cantidad de coches en función de la zona por meses") + 
        theme(plot.background = element_rect(fill = "#353C42"),
              panel.background = element_rect(fill = "#353C42"),
              legend.background = element_rect(fill = "#353C42"),
              plot.title = element_text(family="Montserrat",colour = "white",hjust = 0.5, size = 20),
              text = element_text(family="Montserrat",colour = "white"),
              axis.line = element_line(colour = "white",size = 2),
              panel.grid.major = element_line(color = "lightgrey", size = 0.5),
              panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
              axis.text = element_text(family="Montserrat",colour = "white"))+
        scale_color_brewer(palette="Set1")
    }
    
    return(ggplotly(graf))
  })
  
  funcionGrafico4 = function(){
    graf = muestreado %>% 
                      ggplot(aes(x = IMD_1, y = valor, col = param))+
                      geom_point()+
                      geom_smooth(method = "lm",se = T)+
                      facet_wrap(.~param, scales = "free", ncol = 2)  + 
                      labs(x = "", y = "Contaminación", title = "Relación de la contaminación con la cantidad de coches") +
                      theme(plot.background = element_rect(fill = "#353C42"),
                            panel.background = element_rect(fill = "#353C42"),
                            legend.background = element_rect(fill = "#353C42"),
                            plot.title = element_text(colour = "white",hjust = 0.5, size = 20,family="Montserrat"),
                            text = element_text(colour = "white",family="Montserrat"),
                            axis.line = element_line(colour = "white",size = 2),
                            panel.grid.major = element_line(color = "lightgrey", size = 0.5),
                            panel.grid.minor = element_line(color = "lightgrey", size = 0.5),
                            axis.text = element_text(colour = "white",family="Montserrat"),
                            strip.text = element_text(colour = "#353C42", family="Montserrat"))+
                      scale_color_brewer(palette="Set1")
    return(ggplotly(graf))
  }
}


shinyApp(ui, server)


